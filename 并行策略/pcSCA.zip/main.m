%  Sine Cosine Algorithm (SCA)  
%
%  Source codes demo version 1.0                                                                      
%                                                                                                     
%  Developed in MATLAB R2011b(7.13)                                                                   
%                                                                                                     
%  Author and programmer: Seyedali Mirjalili                                                          
%                                                                                                     
%         e-Mail: ali.mirjalili@gmail.com                                                             
%                 seyedali.mirjalili@griffithuni.edu.au                                               
%                                                                                                     
%       Homepage: http://www.alimirjalili.com                                                         
%                                                                                                     
%  Main paper:                                                                                        
%  S. Mirjalili, SCA: A Sine Cosine Algorithm for solving optimization problems
%  Knowledge-Based Systems, DOI: http://dx.doi.org/10.1016/j.knosys.2015.12.022
%_______________________________________________________________________________________________
% You can simply define your cost function in a seperate file and load its handle to fobj 
% The initial parameters that you need are:
%__________________________________________
% fobj = @YourCostFunction
% dim = number of your variables
% Max_iteration = maximum number of iterations
% SearchAgents_no = number of search agents
% lb=[lb1,lb2,...,lbn] where lbn is the lower bound of variable n
% ub=[ub1,ub2,...,ubn] where ubn is the upper bound of variable n
% If all the variables have equal lower bound you can just
% define lb and ub as two single numbers

% To run SCA: [Best_score,Best_pos,cg_curve]=SCA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj)
%______________________________________________________________________________________________

clear
D = 20;
Vmin=-10;
Vmax=10;
popmax = 100;
popmin = -100;
pop_size = 30; % Number of search agents
iter_max = 1000;% Maximum numbef of iterations
fhd=str2func('cec13_func');

% Load details of the selected benchmark function
% [lb,ub,dim,fobj]=Get_Functions_details(Function_name)
data = zeros(5,30);
result = zeros(5,5);
% Test function from 1 to 20
for fun_no = 1:28
    disp(['===========Iteration fun_no is ',num2str(fun_no),'===========']);
    for i = 1:pop_size
        disp(['--Iteration fun_no is ',num2str(fun_no),'Iteration i is ',num2str(i),'--']);
        [Best_score_1] = SCA(fhd,D,pop_size,iter_max,popmin,popmax,fun_no);
        [Best_score_2] = PSCA(fhd,D,pop_size,iter_max,popmin,popmax,fun_no);
        [Best_score_3] = PSO(fhd,D,pop_size,iter_max,Vmin,Vmax,popmin,popmax,fun_no);
        [Best_score_4] = pcCS(fhd,D,pop_size,iter_max,popmin,popmax,fun_no);
        [Best_score_5] = GWO(fhd,D,pop_size,iter_max,popmin,popmax,fun_no);
        [Best_score_6] = pcSCA_s1(fhd,D,pop_size,iter_max,popmin,popmax,fun_no);
        [Best_score_7] = pcSCA_s2(fhd,D,pop_size,iter_max,popmin,popmax,fun_no);
        [Best_score_8] = pcSCA_s3(fhd,D,pop_size,iter_max,popmin,popmax,fun_no);
        
        data(1,i) = Best_score_1;
        data(2,i) = Best_score_2;
        data(3,i) = Best_score_3;
        data(4,i) = Best_score_4;
        data(5,i) = Best_score_5;
        data(6,i) = Best_score_6;
        data(7,i) = Best_score_7;
        data(8,i) = Best_score_8;
    end
    result(fun_no,1) = mean(data(1,:));
    result(fun_no,2) = mean(data(2,:));
    result(fun_no,3) = mean(data(3,:));
    result(fun_no,4) = mean(data(4,:));
    result(fun_no,5) = mean(data(5,:));
    result(fun_no,6) = mean(data(6,:));
    result(fun_no,7) = mean(data(7,:));
    result(fun_no,8) = mean(data(8,:));
end

% for fun_no = 1:2
%     disp(['================================Iteration fun_no is ',num2str(fun_no),'=========== ']);
%     for i = 1:30
%         disp(['-------------Iteration fun_no is ',num2str(fun_no),'   Iteration i is ',num2str(i),'--']);    
%         [Best_score_1] = GWO(fhd,D,pop_size,iter_max,popmin,popmax,fun_no);
%         data(fun_no,i) = Best_score_1;
%     end
%     result(fun_no,1) = mean(data(fun_no,:));
% end
   



