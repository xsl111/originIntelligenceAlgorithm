function [Destination_fitness,Destination_position_x,Destination_position_y,Destination_position_hop,Convergence_curve]=pcSCA_application_s3(N,Max_iteration,R,lb,ub,dim)
% virtual population size
Np=N;
% the node numbers
Nd = dim;
count = 1;
groups = 6;%divide in six groups
disp('parallel compact SCA is optimizing your problem');
% 保存边界到 Lb Ub
if size(ub,2) == 1
    %如果上边界只有一列，统一边界维度
    Lb = lb*ones(1,Nd);
    Ub = ub*ones(1,Nd);
else % 则等于原上下边界
    Lb = lb;
    Ub = ub;
end

%Initialize the set of random solutions
for g = 1:groups
    group(g).mu_x = zeros(1,Nd);
    group(g).sicma_x = 10*ones(1,Nd);
    group(g).mu_y = zeros(1,Nd);
    group(g).sicma_y = 10*ones(1,Nd);
    group(g).fmin = inf;
    group(g).best_position_x = Ub;
    group(g).best_position_y = Ub;
    group(g).dvhop_position = zeros(2,Nd);
end

% Global best fitness and position 
Destination_fitness = group(1).fmin;
Destination_position_x = group(1).best_position_x;
Destination_position_y = group(1).best_position_y;
Destination_position_hop = zeros(2,Nd); % maintain the position of DV-hop

% 收敛曲线
Convergence_curve = zeros(1,Max_iteration);
Convergence_curve(count) = Destination_fitness;

%Main loop
for t = 2:Max_iteration
    count = count + 1;
    % Eq. (3.4)
    a = 2;
    r1 = a-t*((a)/Max_iteration); % r1 decreases linearly from a to 0
    w1 = abs(sin(2*pi*t/Max_iteration));
    w2 = 1.0 - w1;
    % Update the position of solutions with respect to destination
    for g = 1:groups
        %每一组进行Np次生成与比较，类似PSCA对每一组Np个解的每一维都
        % 根据PV生成一个随机解
        agent_x = zeros(1,Nd);
        agent_y = zeros(1,Nd);
        for i = 1:Nd
            agent_x(i) = generateCDFInv(rand,group(g).mu_x(i),group(g).sicma_x(i));
            agent_x(i) = agent_x(i)*((Ub(i)-Lb(i))/2) + ((Ub(i)+Lb(i))/2);
            agent_y(i) = generateCDFInv(rand,group(g).mu_y(i),group(g).sicma_y(i));
            agent_y(i) = agent_y(i)*((Ub(i)-Lb(i))/2) + ((Ub(i)+Lb(i))/2);
        end
        agentsca_x = zeros(1,Nd);
        agentsca_y = zeros(1,Nd);
        % 从每一个点执行SCA操作
        for i = 1:Nd% in i-th solution
            % Update r2, r3, and r4 for Eq. (3.3)
            r2 = (2*pi)*rand();
            r3 = 2*rand;
            r4 = rand();
            % Eq. (3.3)
            if r4 < 0.5
                % Eq. (3.1) 
                agentsca_x(i) = agent_x(i)+(r1*sin(r2)*abs(r3*group(g).best_position_x(i)-agent_x(i)));
                agentsca_y(i) = agent_y(i)+(r1*sin(r2)*abs(r3*group(g).best_position_y(i)-agent_y(i)));
            else
                % Eq. (3.2) 
                agentsca_x(i) = agent_x(i)+(r1*cos(r2)*abs(r3*group(g).best_position_x(i)-agent_x(i)));
                agentsca_y(i) = agent_y(i)+(r1*cos(r2)*abs(r3*group(g).best_position_y(i)-agent_y(i)));
            end
        end
        % 这里agentsca会越界保证agentsca在边界内
        agentsca_x = simplebounds(agentsca_x,Lb,Ub);
        agentsca_y = simplebounds(agentsca_y,Lb,Ub);
        % 传入两个点分布组，进行比较
        [wx,wy,lx,ly,~,~] = competetwo(agent_x,agent_y,agentsca_x,agentsca_y,R,Nd,w1,w2);
        % Update PV
        for i=1:Nd
            %将winner和loser映射到[-1,1]
            wx(i) = (wx(i)-(Ub(i)+Lb(i))/2)/((Ub(i)-Lb(i))/2);
            lx(i) = (lx(i)-(Ub(i)+Lb(i))/2)/((Ub(i)-Lb(i))/2);
            wy(i) = (wy(i)-(Ub(i)+Lb(i))/2)/((Ub(i)-Lb(i))/2);
            ly(i) = (ly(i)-(Ub(i)+Lb(i))/2)/((Ub(i)-Lb(i))/2);
            mut_x = group(g).mu_x(i);
            mut_y = group(g).mu_y(i);
            group(g).mu_x(i) = mut_x + (1/Np)*(wx(i)-lx(i));
            group(g).mu_y(i) = mut_y + (1/Np)*(wy(i)-ly(i));
            temp_x = group(g).sicma_x(i)^2+mut_x^2-group(g).mu_x(i)^2+(1/Np)*(wx(i)^2-lx(i)^2);
            if temp_x>0
                group(g).sicma_x(i) = sqrt(temp_x);
            else
                group(g).sicma_x(i) = 10;
            end
            temp_y = group(g).sicma_y(i)^2+mut_y^2-group(g).mu_y(i)^2+(1/Np)*(wy(i)^2-ly(i)^2);
            if temp_y > 0
                group(g).sicma_y(i) = sqrt(temp_y);
            else
                group(g).sicma_y(i) = 10;
            end
        end
        % 到这里winner已经变为[-1,1]区间，需要转换回原区间
        wx = change_interval(wx,Lb,Ub,Nd);
        wy = change_interval(wy,Lb,Ub,Nd);
        [wx,wy,~,~,winner_fit,position] = competetwo(wx,wy,group(g).best_position_x,group(g).best_position_y,R,Nd,w1,w2);
        
        % 更新组内最优
        group(g).best_position_x = wx;
        group(g).best_position_y = wy;
        group(g).fmin = winner_fit;
        group(g).dvhop_position = position;
    end
    for g = 1:groups
        if group(g).fmin < Destination_fitness
            Destination_fitness = group(g).fmin;
            Destination_position_x = group(g).best_position_x;
            Destination_position_y = group(g).best_position_y;
            Destination_position_hop = group(g).dvhop_position;
        end
    end
    Convergence_curve(count) = Destination_fitness;
    if mod(t,200) == 0
        display(['At iteration ', num2str(t), ' the optimum is ', num2str(Destination_fitness)]);
    end
    %组内交流
    for g = 1:groups
        sg = mod(g+2,groups);
        if sg == 0
             sg = 1;
        end
        while( mod(sg,groups) ~= g-1)
            r  = rand();
            if r < 0.5
                if group(g).fmin > group(sg).fmin
                    w = sg;
                    l = g;
                else
                    w = g;
                    l = sg;
                end
                group(l).fmin = group(w).fmin;
                group(l).best_position_x = group(w).best_position_x;
                group(l).best_position_y = group(w).best_position_y;
                group(l).dvhop_position = group(2).dvhop_position;
                
                new_rd_x = group(w).best_position_x + (dist(Ub,Lb')/50)*rand.*randn(1,Nd);
                new_rd_y = group(w).best_position_y + (dist(Ub,Lb')/50)*rand.*randn(1,Nd);
                objective_value = fitness(new_rd_x(1,:),new_rd_y(1,:));
                [~,average_error,position] = DV_Hop(Nd,R,new_rd_x,new_rd_y);
                if isnan(average_error)
                    fit_rd = objective_value;
                else
                    fit_rd = w1*objective_value + w2*average_error;
                end
                if fit_rd < group(g).fmin
                    group(w).fmin = fit_rd;
                    group(w).best_position_x = new_rd_x;
                    group(w).best_position_y = new_rd_y;
                    group(w).dvhop_position = position;
                end
            else
                gene_x(1,:) = group(g).best_position_x;
                gene_x(2,:) = Destination_position_y;
                gene_y(1,:) = group(g).best_position_x;
                gene_y(2,:) = Destination_position_y;
                for i = 1:size(gene_x,2)
                    r = rand();
                    if r < 0.5
                        new_rd_x(i) = gene_x(1,i);
                        new_rd_y(i) = gene_y(1,i);
                    else
                        new_rd_x(i) = gene_x(2,i);
                        new_rd_y(i) = gene_y(2,i);
                    end
                end
                [~,average_error,position] = DV_Hop(Nd,R,new_rd_x,new_rd_y);
                objective_value = fitness(position(1,:),position(2,:));
                if isnan(average_error)
                    fit_rd = objective_value;
                else
                    fit_rd = w1*objective_value + w2*average_error;
                end
                if fit_rd < group(g).fmin
                    group(g).fmin = fit_rd;
                    group(g).best_position_x = new_rd_x;
                    group(g).best_position_y = new_rd_y;
                    group(g).dvhop_position = position;
                end
            end
            if sg == 6
                sg = 1;
            else
                sg = sg + 1;
            end
        end
    end
end
end
% 根据rand(),mu,sigma 生成 随机样本
function samplerand = generateCDFInv(r,mu,sigma)
% mu = 0;
% sigma = 10;
erfA = erf((mu+1)/(sqrt(2)*sigma));
erfB = erf((mu-1)/(sqrt(2)*sigma));
samplerand = erfinv(-erfA-r*erfB+r*erfA)*sigma*sqrt(2)+mu;
end
%compete two individual
function [wx,wy,lx,ly,winner_fit,position]=competetwo(agent_x,agent_y,agentsca_x,agentsca_y,R,Nd,w1,w2)
% 计算覆盖率和定位误差，采用动态权重的方式
[~,average_error_1,position_1] = DV_Hop(Nd,R,agent_x,agent_y);
objective_value_1 = fitness(agent_x,agent_y);

[~,average_error_2,position_2] = DV_Hop(Nd,R,agentsca_x,agentsca_y);
objective_value_2 = fitness(agentsca_x,agentsca_y);
if isnan(average_error_1) || isnan(average_error_2)
    if isnan(average_error_1)
        f1 = objective_value_1;
    else
        f1 = w1*objective_value_1 + w2*average_error_1;
    end
    if isnan(average_error_2)
        f2 = objective_value_2;
    else
        f2 = w1*objective_value_2 + w2*average_error_2;
    end
else
    f1 = w1*objective_value_1 + w2*average_error_1;
    f2 = w1*objective_value_2 + w2*average_error_2;
end

if f1 < f2
    wx = agent_x;   wy = agent_y;
    lx = agentsca_x;ly = agentsca_y;
    winner_fit = f1;
    position = position_1;
else
    lx = agent_x;   ly = agent_y;
    wx = agentsca_x;wy = agentsca_y;
    winner_fit = f2;
    position = position_2;
end
end
% Application of simple constraints， 更新边界
function s = simplebounds(s,Lb,Ub)
% Apply the lower bound
ns_tmp = s;
I = ns_tmp < Lb; % 如果比下边界要小
ns_tmp(I) = Lb(I); % 替换为下边界

% Apply the upper bounds
J= ns_tmp > Ub;
ns_tmp(J) = Ub(J);
% Update this new move
s = ns_tmp;
end

function s=change_interval(s,Lb,Ub,Nd)
for i=1:Nd
    s(i) = s(i)*((Ub(i)-Lb(i))/2) + ((Ub(i)+Lb(i))/2);
end
end