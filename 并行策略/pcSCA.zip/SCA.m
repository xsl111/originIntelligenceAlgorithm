
% fhd = cec13_func
% dim = number of your variables
% Max_iteration = maximum number of iterations
% N = number of search agents
% lb=[lb1,lb2,...,lbn] where lbn is the lower bound of variable n
% ub=[ub1,ub2,...,ubn] where ubn is the upper bound of variable n
% Iif all the variables have equal lower bound you can just
% define lb and ub as two single numbers

function [Destination_fitness]=SCA(fhd,dim,N,Max_iteration,lb,ub,fun_no)

display('SCA is optimizing your problem');

%Initialize the set of random solutions 
X=initialization(N,dim,ub,lb);

% global best agent fitness
Destination_fitness=inf;
% global best position
Destination_position=zeros(1,dim);
% Calculate the fitness of the first set and find the best one
Objective_values = feval(fhd,X',fun_no);

Destination_position=X(1,:);
Destination_fitness=Objective_values(1,1);
for i=2:size(X,1) 
    % fitness function objective_value
    if Objective_values(1,i)<Destination_fitness
        Destination_position=X(i,:);
        Destination_fitness=Objective_values(1,i);
    end
end
%Main loop
t=2; % start from the second iteration since the first iteration was dedicated to calculating the fitness
while t<=Max_iteration
    
    % Eq. (3.4)
    a = 2; % constant value 
    %Max_iteration = Max_iteration;
    r1=a-t*((a)/Max_iteration); % r1 decreases linearly from a to 0
    % Update the position of solutions with respect to destination
    for i=1:size(X,1) % in i-th solution
        for j=1:size(X,2) % in j-th dimension
            
            % Update r2, r3, and r4 for E q. (3.3)
            r2=(2*pi)*rand();
            r3=2*rand;
            r4=rand();
            
            % 更新i-th agent 的 j dim
            % Eq. (3.3)
            if r4<0.5
                % Eq. (3.1)
                X(i,j)= X(i,j)+(r1*sin(r2)*abs(r3*Destination_position(j)-X(i,j)));
            else
                % Eq. (3.2)
                X(i,j)= X(i,j)+(r1*cos(r2)*abs(r3*Destination_position(j)-X(i,j)));
            end
            
        end
    end
    
    for i=1:size(X,1)
         
        % Check if solutions go outside the search space and bring them back
        Flag4ub=X(i,:)>ub;
        Flag4lb=X(i,:)<lb;
        % 更新边界
        X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        
        % Calculate the objective values
        Objective_values(1,i) = feval(fhd,X(i,:)',fun_no);
        % Update the destination if there is a better solution
        if Objective_values(1,i)<Destination_fitness
            Destination_position=X(i,:);
            Destination_fitness=Objective_values(1,i);
        end
    end
    
    % Display the iteration and best optimum obtained so far 每50打印一次
    if mod(t,200)==0
        display(['At iteration ', num2str(t), ' the optimum is ', num2str(Destination_fitness)]);
    end
    
    % Increase the iteration counter
    t=t+1;
end