function [fitnessgbest] = PSO( fhd,Dimension,Particle_Number,Max_Gen,VRmin,VRmax,Popmin,Popmax,varargin )


rand('state',sum(100*clock));

c = 2.0;
w = 0.9;
D = Dimension;
sizepop = Particle_Number;
maxgen = Max_Gen;
Vmax = VRmax;
Vmin = VRmin;
popmax = Popmax;
popmin = Popmin;
for i = 1:sizepop
    pop(i,:) = popmin+(popmax-popmin)*rand(1,D);    %��ʼ��Ⱥ
    V(i,:) = Vmin+(Vmax-Vmin)*rand(1,D);  %��ʼ���ٶ�
end
fitness = feval(fhd,pop',varargin{:});

[bestfitness,bestindex] = min(fitness);
pbest = pop;    
gbest = pop(bestindex,:);   
fitnesspbest = fitness;
fitnessgbest = bestfitness;

for G = 1:maxgen
    
    for i = 1:sizepop
        V(i,:) = w*V(i,:)+c*rand*(pbest(i,:) -pop(i,:))+c*rand*(gbest-pop(i,:));
        for d = 1:D
            V(i,d) = max(Vmin,min(Vmax,V(i,d)));
        end
        
        pop(i,:) = pop(i,:)+V(i,:);
        
        for d = 1:D
            pop(i,d) = max(popmin,min(popmax,pop(i,d)));
        end
        
        
    end
    fitness = feval(fhd,pop',varargin{:});
    for i = 1:sizepop
        if fitness(i)<fitnesspbest(i)
            fitnesspbest(i) = fitness(i);
            pbest(i,:) = pop(i,:);
        end
        
        if fitness(i)<fitnessgbest
            fitnessgbest = fitness(i);
            gbest = pop(i,:);
        end
    end
end

end

