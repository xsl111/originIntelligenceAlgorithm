
function [Destination_fitness]=PSCA(fhd,dim,N,Max_iteration,lb,ub,fun_no)

groups = 6;%divide in two groups
disp('PSCA is optimizing your problem');
w_max = 0.8;
w_min = 0.1;
%Initialize the set of random solutions
for g=1:groups
    group(g).pop = rand(N/6,dim).*(ub-lb)+lb; % 初始化赋值了所有点
    group(g).Objective_values = zeros(1,size(group(g).pop,1));%所有agent fitness value
    group(g).fitness = inf; % 组内最佳fitness
    group(g).Destination_position = zeros(1,dim); % 组队最佳agent position
end

Destination_fitness=inf;
Destination_position=zeros(1,dim);

%Objective_values = zeros(1,size(X,1));

% Calculate the fitness of the first set and find the best one
for g=1:groups
    X = group(g).pop; % 取出组内agent position
    for i=1:size(X,1)
        group(g).Objective_values(1,i) = feval(fhd,X(i,:)',fun_no); % fitness value
        if i==1
            group(g).Destination_position=X(i,:);
            group(g).fitness=group(g).Objective_values(1,i);
        elseif group(g).Objective_values(1,i) < group(g).fitness
            group(g).Destination_position=X(i,:);
            group(g).fitness=group(g).Objective_values(1,i);
        end
    end
    if group(g).fitness < Destination_fitness
        Destination_position=group(g).Destination_position;
        Destination_fitness = group(g).fitness;
    end
end
%disp(X);
%Main loop
t=2; % start from the second iteration since the first iteration was dedicated to calculating the fitness
while t<=Max_iteration
    % Eq. (3.4)
    a = 2;
    r1=a-t*((a)/Max_iteration); % r1 decreases linearly from a to 0
    w = w_max-(w_max-w_min)*(t/Max_iteration);
    % Update the position of solutions with respect to destination
    for g=1:groups
        X = group(g).pop;
        for i=1:size(X,1)% in i-th solution
            for j=1:size(X,2)% in j-th dimension
                % Update r2, r3, and r4 for Eq. (3.3)
                r2=(2*pi)*rand();
                r3=2*rand;
                r4=rand();
                % Eq. (3.3)
                if r4<0.5
                    % Eq. (3.1)
                    %X(i,j)= w*X(i,j)+(r1*sin(r2)*abs(r3*group(g).Destination_position(j)-X(i,j)));
                    X(i,j)= X(i,j)+(r1*sin(r2)*abs(r3*group(g).Destination_position(j)-X(i,j)));
                else
                    % Eq. (3.2)
                    %X(i,j)= w*X(i,j)+(r1*cos(r2)*abs(r3*group(g).Destination_position(j)-X(i,j)));
                    X(i,j)= X(i,j)+(r1*cos(r2)*abs(r3*group(g).Destination_position(j)-X(i,j)));
                end
            end
        end
        % 对所有粒子防越界
        for i=1:size(X,1)
            % Check if solutions go outside the search spaceand bring them back
            Flag4ub=X(i,:)>ub;
            Flag4lb=X(i,:)<lb;
            X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
            % Calculate the objective values
            group(g).Objective_values(1,i) = feval(fhd,X(i,:)',fun_no);
            % Update the destination if there is a better solution
            if group(g).Objective_values(1,i) < group(g).fitness
                group(g).Destination_position=X(i,:);
                group(g).fitness=group(g).Objective_values(1,i);
            end
        end
        group(g).pop = X; % 存回去
        if group(g).fitness < Destination_fitness%全局fitness
            Destination_position = group(g).Destination_position;
            Destination_fitness = group(g).fitness;
        end
    end

    if mod(t,50) == 0
        for g=1:groups
            if Destination_fitness < group(g).fitness
                group(g).fitness = Destination_fitness;
                group(g).Destination_position = Destination_position;
            end
        end
    end
    if mod(t,200) == 0
        display(['At iteration ', num2str(t), ' the optimum is ', num2str(Destination_fitness)]);
    end
    % Increase the iteration counter
    t=t+1;
end