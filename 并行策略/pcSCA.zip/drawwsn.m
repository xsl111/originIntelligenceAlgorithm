function drawwsn(sx,sy,SensorNum,R,w,nodex,nodey)
%% Visualize the best solution of deployment of WSN
% @author: Shangru Zhong
% @email: draco.mystack@gmail.com
% @date: 11/01/2013

alpha1=0:pi/50:2*pi;
figure(1)
hold on;
for Pxy=1:SensorNum 
    x=sx(Pxy)+R*cos(alpha1);
    y=sy(Pxy)+R*sin(alpha1);
    %plot(x,y,'-');
    fill(x,y,'b','facealpha',0.3);
end
plot(sx,sy,'k.');   
plot(nodex(1,:), nodey(1,:),'g.')
% plot(sx,sy,'k.');   
axis equal
axis([0 w 0 w])
hold off;

figure(2);
hold on;
for Pxy=1:SensorNum                 
    x=nodex(Pxy)+R*cos(alpha1);
    y=nodey(Pxy)+R*sin(alpha1);
    %plot(x,y,'-');
    fill(x,y,'b','facealpha',0.3);
end
plot(nodex,nodey,'k.');    
axis equal
axis([0 w 0 w])
plot(sx(1,:), sy(1,:),'r.')
hold off;