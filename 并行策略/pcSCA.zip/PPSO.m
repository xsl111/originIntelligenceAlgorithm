function [TotalBest,T] = PPSO( fhd,Dimension,Particle_Number,Max_Gen,VRmin,VRmax,Popmin,Popmax,varargin )
rand('state',sum(100*clock));

c = 2.0;
w = 0.9;
D = Dimension;
groups = 4;
sizepop = Particle_Number/groups;
maxgen = Max_Gen;
Vmax = VRmax;
Vmin = VRmin;
popmax = Popmax;
popmin = Popmin;


for g = 1:groups
    for i = 1:sizepop
        group(g).pop(i,:) = popmin+(popmax-popmin)*rand(1,D);    
        group(g).V(i,:) = Vmin+(Vmax-Vmin)*rand(1,D);  
    end
    group(g).fitness = feval(fhd,group(g).pop',varargin{:});
end

for g = 1:groups
    [group(g).bestfitness,group(g).bestindex] = min(group(g).fitness);
    group(g).GP = group(g).bestindex;
    group(g).pbest = group(g).pop;    
    group(g).gbest = group(g).pop(group(g).bestindex,:);   
    group(g).fitnesspbest = group(g).fitness;
    
    group(g).fitnessgbest = group(g).bestfitness;
    
    TotalBest = group(1).fitnessgbest;
    TotalBestPosition = group(1).gbest;
   
end
for g = 1:groups
    if group(g).fitnessgbest<TotalBest
        TotalBest = group(g).fitnessgbest;
        TotalBestPosition = group(g).gbest;
    end
end


for G = 1:maxgen
    for g = 1:groups
        if rem(G,20) == 0
            RH = int8(rand*sizepop);
            RE = RH+int8(rand*(sizepop/4));
            RH = max(1,min(sizepop,RH));
            RE = max(1,min(sizepop,RE));
            for r = RH:RE
                for d = 1:D
                    group(g).pop(r,d) = TotalBestPosition(d)*(0.9+0.2*rand);
                    
                end
                group(g).pbest(r,:) = TotalBestPosition;
                group(g).fitnesspbest(r) = TotalBest;
            end
            group(g).gbest = TotalBestPosition;
            group(g).fitnessgbest = TotalBest;
        end
        for i = 1:sizepop
            group(g).V(i,:) = w*group(g).V(i,:)+c*rand*(group(g).pbest(i,:)...
                -group(g).pop(i,:))+c*rand*(group(g).gbest-group(g).pop(i,:));
            
            for d = 1:D
                group(g).V(i,d) = max(Vmin,min(Vmax,group(g).V(i,d)));
            end
            
            group(g).pop(i,:) = group(g).pop(i,:)+group(g).V(i,:);
            for d = 1:D
                group(g).pop(i,d) = max(popmin,min(popmax,group(g).pop(i,d)));
            end
            
            
        end
        group(g).fitness = feval(fhd,group(g).pop',varargin{:});
        for i = 1:sizepop
            if group(g).fitness(i)<group(g).fitnesspbest(i)
                group(g).fitnesspbest(i) = group(g).fitness(i);
                group(g).pbest(i,:) = group(g).pop(i,:);
            end
            
            if group(g).fitness(i)<group(g).fitnessgbest
                group(g).fitnessgbest = group(g).fitness(i);
                group(g).gbest = group(g).pop(i,:);
%                 group(g).GP = i;
            end
        end
        if group(g).fitnessgbest <TotalBest
            TotalBest = group(g).fitnessgbest;
            TotalBestPosition = group(g).gbest;
        end
    end

end

end

