function [Destination_fitness]=pcSCA_s1(fhd,dim,Np,Max_iteration,lb,ub,fun_no)

global initial_flag; % the global flag used in test suite 
% DO NOT FORGET
initial_flag = 0; % should set the flag to 0 for each run, each function

% the dimension of question
Nd=dim;
count=1;
groups = 6;
disp('parallel compact SCA is optimizing your problem');
% 保存边界到 Lb Ub
if size(ub,2)==1
    %如果上边界只有一列，统一边界维度
    Lb=lb*ones(1,Nd);
    Ub=ub*ones(1,Nd);
else % 则等于原上下边界
    Lb=lb;
    Ub=ub;
end

%Initialize the set of random solutions
for g=1:groups
    group(g).mu = zeros(1,Nd);
    group(g).sicma = 10*ones(1,Nd);
    group(g).fmin = inf;
    group(g).best_position = Ub;
end
Destination_fitness=group(1).fmin;
Destination_position=group(1).best_position;


%Main loop
for t=2:Max_iteration
    count = count + 1;
    % Eq. (3.4)
    a = 2;
    r1=a-t*((a)/Max_iteration); % r1 decreases linearly from a to 0
    % Update the position of solutions with respect to destination
    for g=1:groups
        %每一组进行Np次生成与比较，类似PSCA对每一组Np个解的每一维都
%         for x=1:Np/groups
            % 根据PV生成一个随机解
            agent=zeros(1,Nd);
            for i=1:Nd
                agent(i)=generateCDFInv(rand,group(g).mu(i),group(g).sicma(i));
                agent(i) = agent(i)*((Ub(i)-Lb(i))/2) + ((Ub(i)+Lb(i))/2);
            end
            % levy_flight
            % agentsca=levy_flight(agent,group(g).best_position,Lb,Ub);
            agentsca = zeros(1,Nd);
            % 从每一维对生成的agent执行SCA操作
            for i=1:Nd% in i-th solution
                % Update r2, r3, and r4 for Eq. (3.3)
                r2=(2*pi)*rand();
                r3=2*rand;
                r4=rand();
                % Eq. (3.3)
                if r4<0.5
                    % Eq. (3.1) 
                    agentsca(i)= agent(i)+(r1*sin(r2)*abs(r3*group(g).best_position(i)-agent(i)));
                else
                    % Eq. (3.2)
                    agentsca(i)= agent(i)+(r1*cos(r2)*abs(r3*group(g).best_position(i)-agent(i)));
                end
            end
            % 这里agentsca会越界保证agentsca在边界内
            agentsca = simplebounds(agentsca,Lb,Ub);
            [winner,loser,~]=competetwo(agent,agentsca,fhd,fun_no);
            % Update PV
            for i=1:Nd
                %将winner和loser映射到[-1,1]
                winner(i) = (winner(i)-(Ub(i)+Lb(i))/2)/((Ub(i)-Lb(i))/2);
                loser(i) = (loser(i)-(Ub(i)+Lb(i))/2)/((Ub(i)-Lb(i))/2);
                mut = group(g).mu(i);
                group(g).mu(i) = mut + (1/Np)*(winner(i)-loser(i));
                temp = group(g).sicma(i)^2+mut^2-group(g).mu(i)^2+(1/Np)*(winner(i)^2-loser(i)^2);
                if temp>0
                    group(g).sicma(i)=sqrt(temp);
                else
                    group(g).sicma(i)=10;
                end
            end
            % 到这里winner已经变为[-1,1]区间，需要转换回原区间
            winner=change_interval(winner,Lb,Ub,Nd);
            [winner,~,winner_fit]=competetwo(winner,group(g).best_position,fhd,fun_no);
            
            % 更新组内最优
            group(g).best_position = winner;
            group(g).fmin = winner_fit;
%         end
    end
    
    for g=1:groups
        if group(g).fmin<Destination_fitness
            Destination_fitness = group(g).fmin;
            Destination_position = group(g).best_position;
        end
    end
    
    if mod(t,200)==0
        display(['At iteration ', num2str(t), ' the optimum is ', num2str(Destination_fitness)]);
    end
    %组内交流
    for g = 1:groups
        if group(g).fmin > Destination_fitness
            new_rd = zeros(1,Nd);
            for i = 1:Nd
                r = rand();
                if r < 0.5
                    new_rd(i) = group(g).best_position(i);
                else
                    new_rd(i) = Destination_position(i);
                end
            end
            fit_rd = feval(fhd,new_rd',fun_no);
            if fit_rd < group(g).fmin
                group(g).fmin = fit_rd;
                group(g).best_position = new_rd;
            end
        else
            new_rd = Destination_position + (dist(Ub,Lb')/50)*rand.*randn(1,Nd);
            new_rd = simplebounds(new_rd,Lb,Ub);
            fit_rd = feval(fhd,new_rd',fun_no);
            if fit_rd < group(g).fmin
                group(g).fmin = fit_rd;
                group(g).best_position = new_rd;
            end
        end
    end
    
end
end

% 根据rand(),mu,sigma 生成 随机样本
function samplerand = generateCDFInv(r,mu,sigma)
% mu = 0;
% sigma = 10;
erfA = erf((mu+1)/(sqrt(2)*sigma));
erfB = erf((mu-1)/(sqrt(2)*sigma));
samplerand = erfinv(-erfA-r*erfB+r*erfA)*sigma*sqrt(2)+mu;
end
%compete two individual
function [w,l,winner_fit]=competetwo(x,y,fhd,fun_no)
fx = feval(fhd,x',fun_no);
fy = feval(fhd,y',fun_no);
if fx<fy
    w=x; l=y;
    winner_fit = fx;
else
    w=y; l=x;
    winner_fit = fy;
end
end
% Application of simple constraints， 更新边界
function s=simplebounds(s,Lb,Ub)
% Apply the lower bound
ns_tmp=s;
I=ns_tmp<Lb; % 如果比下边界要小
ns_tmp(I)=Lb(I); % 替换为下边界

% Apply the upper bounds
J=ns_tmp>Ub;
ns_tmp(J)=Ub(J);
% Update this new move
s=ns_tmp;
end

function agentsca=levy_flight(agentsca,best,Lb,Ub)
% Levy flights
n=size(agentsca,1); % n=1
% disp(num2str(n));  25 nest number
% Levy exponent and coefficient
% For details, see equation (2.21), Page 16 (chapter 2) of the book
% X. S. Yang, Nature-Inspired Metaheuristic Algorithms, 2nd Edition, Luniver Press, (2010).
beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);

for j=1:n
    s=agentsca(j,:); % 取出第一行所有列，也就是nest
    %disp(num2str(size(s)));  size(s) = 1,15  
    % This is a simple way of implementing Levy flights
    % For standard random walks, use step=1;
    %% Levy flights by Mantegna's algorithm
    u=randn(size(s))*sigma; % size(s) 返回1,Nd
    v=randn(size(s)); 
    step=u./abs(v).^(1/beta); % equation(5)
  
    % In the next equation, the difference factor (s-best) means that 
    % when the solution is the best solution, it remains unchanged.     
    stepsize=0.01*step.*(s-best);
    % Here the factor 0.01 comes from the fact that L/100 should the typical
    % step size of walks/flights where L is the typical lenghtscale; 
    % otherwise, Levy flights may become too aggresive/efficient, 
    % which makes new solutions (even) jump out side of the design domain 
    % (and thus wasting evaluations).
    % Now the actual random walks or flights
    s=s+stepsize.*randn(size(s));
   % Apply simple bounds/limits
   agentsca(j,:)=simplebounds(s,Lb,Ub);
end
end
function s=change_interval(s,Lb,Ub,Nd)
for i=1:Nd
    s(i) = s(i)*((Ub(i)-Lb(i))/2) + ((Ub(i)+Lb(i))/2);
end
end