function error = fitness(x,y)
%{
point = 100;  %the sensor point covered by WSN 100*100
r = 7; % radius of sensor point coverage region in WSN
w = 100; % with of area 
C=3*r;
re = 0.5*r;
rc = r-re;
rp = r+re;

alpha1= 1;
alpha2= 0;
beta1= 1;
beta2= 0.5;
%}

point = 50;  %the sensor point covered by WSN 100*100
r = 10; % radius of sensor point coverage region in WSN
w = 100; % with of area 
C=3*r;
re = r/2.0;%5
rc = r-re;%5
rp = r+re;

alpha1= 1;
alpha2= 0;
beta1= 1;
beta2= 1.5; 

sensedCth = 0.7; % the threshold of predefined effective detection probability

CoverNum = 0;   
%for Px = 0:99                             
    %for Py = 0:99
% 计算每个像素在这个位置的覆盖情况
% 每一大组有10小组，每一小组有50个粒子，判断这50个粒子的覆盖情况
% 最终返回误差，求最小
for Px = 0:(w-1)                             
    for Py = 0:(w-1)            
        unSensedP = 1; % 默认未覆盖节点
        for S = 1:point % 每一个点   覆盖此像素的情况            
            Distance = (x(S)-Px)^2 + (y(S)-Py)^2;% 计算每一维距离当前像素点的位置
            Distance = sqrt(Distance);
            SensedPi =0;
            if(Distance>r)
			   SensedPi =0;            
            else%探测到了
                SensedPi = 1;
%             else
%                 lda1=re-r+Distance;
%                 lda2=re+r-Distance;
%                 s = (0-alpha1*power(lda1,beta1))/(power(lda2,beta2)+alpha2);
%                 SensedPi =exp(s);
            end
            % 只要被探测到过就是unSensedP=0
            unSensedP=unSensedP*(1.0-SensedPi);
        end
        % 如果此像素被有过一点sensor node覆盖就加入， 
        % 如果有效探索可能性大于sensedCth 就加入
        if(1.0-unSensedP > sensedCth)
                CoverNum = CoverNum + 1;   
        end   
            
    end
end
z=CoverNum/(w^2);     % calculate coverage rate

error =1-z;


end