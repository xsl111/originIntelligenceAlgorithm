function [Accuracy,average_error,position]=DV_Hop(NodeAmount,R,x,y)
% DV-Hop算法
% BorderLength-----正方形区域的边长，单位：m
% NodeAmount-------网络节点的个数
% BeaconAmount---信标节点数
% Sxy--------------用于存储节点的序号，横坐标，纵坐标的矩阵
% Beacon----------信标节点坐标矩阵;BeaconAmount*BeaconAmount
% UN-------------未知节点坐标矩阵;2*UNAmount
% Distance------未知节点到信标节点距离矩阵;2*BeaconAmount
% h---------------节点间初始跳数矩阵
% X---------------节点估计坐标初始矩阵,X=[x,y]'
% R------------------节点的通信距离，一般为10-100m


BeaconAmount=NodeAmount*0.2;
UNAmount=NodeAmount-BeaconAmount;
h=zeros(NodeAmount,NodeAmount);%初始跳数
X=zeros(2,UNAmount);%未知节点初始坐标

Beacon=[x(1,1:BeaconAmount);y(1,1:BeaconAmount)];
UN=[x(1,(BeaconAmount+1):NodeAmount);y(1,(BeaconAmount+1):NodeAmount)];

% plot(x(1,1:BeaconAmount),y(1,1:BeaconAmount),'r*',x(1,(BeaconAmount+1):NodeAmount),y(1,(BeaconAmount+1):NodeAmount),'k.')
% xlim([0,BorderLength]);
% ylim([0,BorderLength]);
% title('The nodes distribution')
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~初始化节点间距离、跳数矩阵~~~~~~~~~~~~~~~~~~~~~~
Dall=zeros(NodeAmount,NodeAmount);
for i=1:NodeAmount
    for j=1:NodeAmount
        Dall(i,j)=((x(1,i)-x(1,j))^2+(y(1,i)-y(1,j))^2)^0.5;%所有节点间相互距离
        if (Dall(i,j)<=R)&&(Dall(i,j)>0)
            h(i,j)=1;%初始化跳数
        elseif i==j
            h(i,j)=0;
        else
            h(i,j)=inf;
        end
    end
end
%~~~~~~~~~~~~~~最短路径算法计算节点间跳数~~~~~~~~~~~~~~~~~~~~
% 如果两点间连接则为1，如果i,k或k,j之间无连接为inf加上则不会更新，只有有连接经过k并且小于一直跳数才会更新
for k=1:NodeAmount
    for i=1:NodeAmount
        for j=1:NodeAmount
            if h(i,k)+h(k,j)<h(i,j)%min(h(i,j),h(i,k)+h(k,j))
                h(i,j)=h(i,k)+h(k,j);
            end
        end
    end
end
%~~~~~~~~~~~~~求每个信标节点的校正值~~~~~~~~~~~~~~~~~~~~~~~~~
h1=h(1:BeaconAmount,1:BeaconAmount);    % 信标节点间跳数
D1=Dall(1:BeaconAmount,1:BeaconAmount); % 信标节点间距离
dhop=zeros(BeaconAmount,1);
for i=1:BeaconAmount
    dhop(i,1)=sum(D1(i,:))/sum(h1(i,:));%每个信标节点的平均每跳距离
end
% D2未知节点到信标节点的距离
D2=Dall(1:BeaconAmount,(BeaconAmount+1):NodeAmount);%BeaconAmount行UNAmount列
Dhop=zeros(1,UNAmount);
for i=1:BeaconAmount
    for j=1:UNAmount
        if min(D2(:,j))==D2(i,j) % 找到D2中距离最近的信标节点
            Dhop(1,j)=dhop(i,1);  % 保存未知节点到最近信标节点的平均跳距
        end
    end
end
%~~~~~~~~~~~~~~~~佣跳数估计距离~~~~~~~~~~~~~~~~~~~
hop1=h(1:BeaconAmount,(BeaconAmount+1):NodeAmount);%未知节点到信标节点的跳数
for i=1:UNAmount
    hop=Dhop(1,i);%hop为从最近的信标获的平均跳距
    Distance(:,i)=hop*hop1(:,i);% 最近信标的平均跳距*到每个信标节点的跳数，得到未知节点到每个信标节点的距离
end
%~~~~~~~~~~~~~~~~~最小二乘法求未知点坐标~~~~~~~~~~~~~~~~~~~~~~~~
for i=1:2
    for j=1:(BeaconAmount-1)
        a(i,j)=Beacon(i,j)-Beacon(i,BeaconAmount);
    end
end
A=-2*(a');
% X 存放最终计算的出的坐标
for m=1:UNAmount
    for i=1:(BeaconAmount-1) % 第i个信标节点和第m个未知节点
        B(i,1)=Distance(i,m)^2-Distance(BeaconAmount,m)^2-Beacon(1,i)^2+Beacon(1,BeaconAmount)^2-Beacon(2,i)^2+Beacon(2,BeaconAmount)^2;
    end
    X1=pinv(A'*A)*A'*B;
    X(1,m)=X1(1,1);
    X(2,m)=X1(2,1);
end
% figure;
% 画出信标节点，未知节点，计算得到的坐标
% plot(x(1,1:BeaconAmount),y(1,1:BeaconAmount),'r*',x(1,(BeaconAmount+1):NodeAmount),y(1,(BeaconAmount+1):NodeAmount),'ko', X(1,1:UNAmount), X(2,1:UNAmount),'gx')
error=zeros(1,UNAmount);
for i=1:UNAmount
    % 误差距离
    error(1,i)=(((X(1,i)-UN(1,i))^2+(X(2,i)-UN(2,i))^2)^0.5);
end
% figure;
% plot(error,'-o')
% title('Error')
% 计算平均误差距离
average_error=sum(error)/UNAmount;
Accuracy=average_error/R;
position=Beacon; 
position(1,(BeaconAmount+1):NodeAmount)=X(1,1:UNAmount);
position(2,(BeaconAmount+1):NodeAmount)=X(2,1:UNAmount);
end

