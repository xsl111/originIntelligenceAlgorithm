function [ Destination_positionX,Destination_positionY,Destination_fitness] = s1(D, ps, VRmin, VRmax )
groups=4;
w_max = 0.8;
w_min = 0.1;
stm = RandStream('swb2712','Seed',sum(100*clock));
RandStream.setGlobalStream(stm);
gen =  1000;
% sensor nodes number
dim=D; % 每一次点数是50
N=ps;%40个，分到4组，每组10个
lb=VRmin;
ub=VRmax;
% 最大迭代数=1000
Max_iteration=gen;
for g=1:groups
    group(g).popX = rand(N/groups,dim).*(ub-lb)+lb;%传感器X坐标
    group(g).popY = rand(N/groups,dim).*(ub-lb)+lb;%传感器Y坐标
    group(g).fitness = inf;%组内最优
    group(g).Objective_values = zeros(1,size(group(g).popX,1));
    group(g).Destination_positionX = zeros(1,dim);%每个节点由50维X，Y组成
    group(g).Destination_positionY = zeros(1,dim);
end
%X=initialization(N,dim,ub,lb);
Destination_fitness=inf;
Convergence_curve=zeros(1,Max_iteration);%
Destination_positionX=zeros(1,dim);%
Destination_positionY=zeros(1,dim);%
% Objective_values = zeros(1,size(X,1));
% Calculate the fitness of the first set and find the best one
for g=1:groups
    X = group(g).popX;
    Y = group(g).popY;
    for i=1:size(X,1)
        % 传入一组X，Y确定的节点，计算这个节点分布的未覆盖率
        group(g).Objective_values(1,i) = fitness(X(i,:),Y(i,:));
        if i==1
            group(g).Destination_positionX=X(i,:);
            group(g).Destination_positionY=Y(i,:);
            group(g).fitness=group(g).Objective_values(1,i);
        elseif group(g).Objective_values(1,i) < group(g).fitness
            group(g).Destination_positionX=X(i,:);
            group(g).Destination_positionX=Y(i,:);
            group(g).fitness=group(g).Objective_values(1,i);
        end
    end
    if group(g).fitness < Destination_fitness % 找出全局最优
        Destination_positionX=group(g).Destination_positionX;
        Destination_positionY=group(g).Destination_positionY;
        Destination_fitness = group(g).fitness;
        Temp.Destination_fitness=inf;
        Temp.Destination_position=[];
    end
end

% Calculate the fitness of the first set and find the best one 
t=2;
mark=0; % start from the second iteration since the first iteration was dedicated to calculating the fitness
while t<=Max_iteration
    % Eq. (3.4)
    a = 2;
    r1=a-t*((a)/Max_iteration); % r1 decreases linearly from a to 0
    w = w_max-(w_max-w_min)*(t/Max_iteration);
    % Update the position of solutions with respect to destination
    for g=1:groups
        X = group(g).popX;
        Y = group(g).popY;
        for i=1:size(X,1) % in i-th solution
            for j=1:size(X,2) % in j-th dimension 
                tempX=X(i,j);
                % Update r2, r3, and r4 for E q. (3.3) 
                while 1
                    r2=(2*pi)*rand();
                    r3=2*rand;
                    r4=rand();
                    % Eq. (3.3)
                    if r4<0.5
                        % Eq. (3.1)
                        tempX=  tempX+(r1*sin(r2)*abs(r3*group(g).Destination_positionX(j)-tempX));
                        %tempY=  tempY+(r1*sin(r2)*abs(r3*Destination_positionY(j)-tempY));
                    else
                        % Eq. (3.2)
                        tempX=  tempX+(r1*cos(r2)*abs(r3*group(g).Destination_positionX(j)-tempX));
                        % tempY=  tempY+(r1*cos(r2)*abs(r3*Destination_positionY(j)- tempY));
                    end
                    % 在要求范围内符合跳出循环，赋值给X(i,j)
                    if(1<tempX&&tempX<100 )
                        break;
                    else % 重新循环
                        tempX=X(i,j);
                    end
                end
                X(i,j)= tempX;
            end
        end
        for i=1:size(Y,1) % in i-th solution 
            for j=1:size(Y,2) % in j-th dimension 
                tempY=Y(i,j);
                % Update r2, r3, and r4 for E q. (3.3) 
                while 1
                    r2=(2*pi)*rand();
                    r3=2*rand;
                    r4=rand();                    
                    % Eq. (3.3)
                    if r4<0.5
                        % Eq. (3.1)
                        %tempX=  tempX+(r1*sin(r2)*abs(r3*Destination_positionX(j)-tempX));
                        tempY=  tempY+(r1*sin(r2)*abs(r3*group(g).Destination_positionY(j)-tempY));
                    else
                        % Eq. (3.2)
                        %tempX=  tempX+(r1*cos(r2)*abs(r3*Destination_positionX(j)-tempX));
                        tempY=  tempY+(r1*cos(r2)*abs(r3*group(g).Destination_positionY(j)- tempY));
                    end
                    if(1<tempY&&tempY<100)
                        break;
                    else
                        tempY=Y(i,j);
                    end
                end 
                Y(i,j)= tempY;
            end
        end
        for i=1:size(X,1)
            % Check if solutions go outside the search spaceand bring them back
            Flag4ub=X(i,:)>ub;
            Flag4lb=X(i,:)<lb;
            X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
            % Calculate the objective values
            group(g).Objective_values(1,i) = fitness(X(i,:),Y(i,:));
            % Update the destination if there is a better solution
            if group(g).Objective_values(1,i) < group(g).fitness
                group(g).Destination_positionX=X(i,:);
                group(g).Destination_positionY=Y(i,:);
                group(g).fitness=group(g).Objective_values(1,i);
            end
        end
        group(g).popX = X;
        group(g).popY = Y;
        if group(g).fitness < Destination_fitness 
            Destination_positionX = group(g).Destination_positionX;
            Destination_positionY = group(g).Destination_positionY;
            Destination_fitness = group(g).fitness;
        end
    end
    Convergence_curve(t)=Destination_fitness;
    % Display the iteration and best optimum obtained so far
    display([num2str(t), ' ', num2str(Destination_fitness)]);
    % 组间交流策略
    if mod(t,10)==0
        for g=1:groups
            if Destination_fitness < group(g).fitness
                for s=1:fix((N/groups)*0.1)
                    [~,b]=max(group(g).Objective_values);
                    group(g).popX(b,:)=Destination_positionX;
                    group(g).popY(b,:)=Destination_positionY;
                end
                group(g).fitness = Destination_fitness;
                group(g).Destination_positionX = Destination_positionX;
                group(g).Destination_positionY = Destination_positionY;
            end
        end
        display(['At iteration ', num2str(t), ' the optimum is ', num2str(Destination_fitness)]);
    end
    % Increase the iteration counter
    t=t+1;
end