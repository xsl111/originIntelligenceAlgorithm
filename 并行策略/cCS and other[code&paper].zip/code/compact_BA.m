%=======================
%   Compact BA
%       Kien-The
%=======================
function value_c_BA=compact_BA(F,Max_gen)
 % Display help
%  help compact_BA.m
 
%  d=20;   %dimensional space

 lamda=10;   %10
 Np=200;     %probability rate
 A=0.5;      % Loudness=0.5  (constant or decreasing)
 r=0.5;      % Pulse rate=0.5 (constant or decreasing)
 Qmin=0;         % Frequency minimum
 Qmax=2;         % Frequency maximum 
 Qi=0;

 [down,up,dim]=test_functions_range(F); % Text function range
% Simple Bound of Search dimension
nd=dim;
if size(up,2)==1
    Lb=down*ones(1,nd);
    Ub=up*ones(1,nd);
else
    Lb=down;
    Ub=up;
end
% 
%  Lb=-5*ones(1,d);    % Lower limit/bounds/ a vector
%  
%  Ub=5*ones(1,d); % Upper limit/bounds/ a vector
 
 
 
 %initialize probability vector PV(mu,sicma)
 mu=zeros(1,nd); %mean
 sicma=lamda*ones(1,nd); %standard deviation
 
 % Initialize the population/solutions
 best=Ub;%Lb+(Ub-Lb).*rand(1,d);%global best initialization %0.5*ones(1,d); 
 fmin=test_functions(best,F,nd);
 v= 0;
%  FES_BA = 1;
 %rand(1,d);  %initialize randomly generate vt 
count=1;   %count the number of iterations
value_c_BA(count)=fmin;
 for t=2:Max_gen      
     count=count+1;
     %generate xlb from probability vecter PV
     x=icdf('Normal',rand(1,nd),mu,sicma);  %reverse function of the cdf function
     
     %update position and velocity
     Qi=Qmin+(Qmax-Qmin)*rand;
     v=v+(x-best)*Qi;
     xnew=x+v;
     
     % Apply simple bounds/limits
     xnew=simplebounds(xnew,Lb,Ub);
     %mu=simplebounds(mu,Lmu,Umu);
     %sicma=simplebounds(sicma,Lsicma,Usicma);
     
     % Pulse rate
     if rand>r
        % The factor 0.001 limits the step sizes of random walks 
       xnew=best+0.1*randn(1,nd);
     end
     
          
     %best selection
     [winner,loser]=compete(xnew,best,F,nd);
     
     %update PV
     for i=1:nd
         munew(i)=mu(i)+(1/Np)*(winner(i)-loser(i));
         sicma(i)=sqrt(sicma(i)*sicma(i) + mu(i)*mu(i)-munew(i)*munew(i)+(1/Np)*(winner(i)*winner(i)-loser(i)*loser(i)));
     end
     
     mu=munew;
     % Evaluate new solutions
     Fnew=test_functions(xnew,F,nd);
%      Fnew=ccs_object_function(xnew);
     % Update if the solution improves, or not too loud
     if (Fnew<=fmin) %& (rand<A) ,
        best=xnew;
        fmin=Fnew;
     end
     
     %best=x;
%      FES_BA = FES_BA + 3;
     %fmin=finess(xgb);
     value_c_BA(count)=fmin;

%      disp(['Best =',num2str(best),' fmin=',num2str(fmin)]);
%      disp(['Mu =',num2str(mu)]);
%      disp(['Sicma =',num2str(sicma)]);
%      disp(['Winner =',num2str(winner)]);
%      disp(['Loser =',num2str(loser)]);
 end
%  save('ccs_value_c_BA.mat','value_c_BA');
%  %hold on;
%  figure (2);
%  %i =1:400;
%  plot(value,'b-');
%  %legend('Bat Algorithm','Compact BA');
%  legend('Compact BA');
%  xlabel('Number of iterations');
% ylabel('Function values ');
end

% Application of simple limits/bounds
function s=simplebounds(s,Lb,Ub)
  % Apply the lower bound vector
  ns_tmp=s;
  I=(ns_tmp<Lb);
  ns_tmp(I)=Lb(I);
  
  % Apply the upper bound vector 
  J=(ns_tmp>Ub);
  ns_tmp(J)=Ub(J);
  % Update this new move 
  s=ns_tmp;
end

%compete two individual
function [u,v]=compete(x,y,F,nd)
if (test_functions(x,F,nd))<(test_functions(y,F,nd))
    u=x; v=y;
else u=y; v=x;
end
end

% %finess funtion
% function z=finess(u)
% % Sphere function with fmin=0 at (0,0,...,0)
% z=sum((u-1).^2);
% % z = sum ( abs(u-3) ) + prod( abs(u-3) );
% end
