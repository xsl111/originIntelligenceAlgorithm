%=======================================
%         <<Artificial Bees Colony>>
%         Original ABC & Compact ABC 
%               Kien 2013
%=======================================
%8888888888888888888888888888888888888888888888888888888888888888888888888
%=========================================================================
%==============================COMPACT ABC================================
%=========================================================================
%9999999999999999999999999999999999999999999999999999999999999999999999999

function value_c_abc = compact_ABC(F,Max_gen)    
   
NP=200; %/* The number of colony size (employed bees+onlooker bees)*/
lamda=8;%1;%8;  % 10
limit=100;
trial=0;%zeros(1,FoodNumber);

[down,up,dim]=test_functions_range(F); % Text function range
% Simple Bound of Search dimension
if size(up,2)==1
    lb=down*ones(1,dim);
    ub=up*ones(1,dim);
else
    lb=down;
    ub=up;
end
    

%Initialize probability vector PV(mu,sicma)
mu=zeros(1,dim);         %mean
sicma=lamda*ones(1,dim); %standard deviation
     
% FES = 0;
tem=ub;
ftem = test_functions(tem,F,dim);
%/*The best food source is memorized*/
sol=tem; 
ObjVal=ftem;
% FES = FES + 1;

Fitness=calculateFitness(ftem);
GlobalMin=ftem;%ObjVal(BestInd);  %fbest
GlobalParams=tem;%Foods(BestInd,:);  %best %vector    


count=1;
value_c_abc(count) = ObjVal;

for iter=2:Max_gen   %interations
    count = count +1;
%     Ret_Fmin1(1,iter)=GlobalMin;    %retain fmin
%         Ret_Time1(1,iter)=toc;     %retain time  
        
    [prob,trial,Fitness,ObjVal,mu,sicma,GlobalParams,sol]=EmployedBeePhase1(dim,Fitness,ObjVal,ub,lb,F,mu,sicma,NP,GlobalParams,sol);

    [trial,GlobalMin,GlobalParams,Fitness,ObjVal,sol]=OnlookerBeePhase1(prob,trial,sol,Fitness,ObjVal,GlobalMin,GlobalParams,dim,ub,lb,F,NP,mu,sicma);

    [sol,Fitness,ObjVal]=ScoutBeePhase1(trial,Fitness,ObjVal,sol,limit,dim,ub,lb,F);
    
%     FES = FES + 5;
    value_c_abc(count)=ObjVal;
end 
% disp(strcat('ccs_value_c_abc '));
% save('ccs_value_c_abc.mat','value_c_abc'); 
end % End of oABC

%========================================================================
%%%%%%%%%%%%%%%%%%%%%%%%% EMPLOYED BEE PHASE1 %%%%%%%%%%%%%%%%%%%%%%%%%%%
function [prob,trial,Fitness,ObjVal,mu,sicma,GlobalParams,sol,x]=EmployedBeePhase1(dim,Fitness,ObjVal,ub,lb,F,mu,sicma,NP,GlobalParams,sol)        
        
    %i=1;
    %FoodNumber=1;
    trial=0;

    sigma2=sicma.^2;
    x=generateIndividualR(mu,sigma2); % User-defined functions  
    %Foods(i,:)=x;
    for i=1:dim
        x(i)=x(i)+rand*x(i);
    end


    x=simplebounds(x,lb,ub);

    %evaluate new solution
    ObjValSol=test_functions(x,F,dim);
    %     ObjValSol=feval(funName(FN),);%(objfun,sol);
    FitnessSol=calculateFitness(ObjValSol);

    if (FitnessSol>Fitness) 
        %Foods(i,:)=sol;
        sol=x;
        Fitness=FitnessSol;
        ObjVal=ObjValSol;
        trial=0;
    else
        trial=trial+1; %/*if the solution i can not be improved, increase its trial counter*/
    end

    
    
    [winner,loser]=compete(sol,GlobalParams,F,dim);        
    mu=updateMuPV(winner,loser,mu,NP,dim);
    sicma=updateSicmaPV(winner,loser,mu,sicma,NP,dim);

    %%%%%%%%%%%%%%%%%%%%%%%% CalculateProbabilities %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %/* A food source is chosen with the probability which is proportioal to its quality*/
    %/*Different schemes can be used to calculate the probability values*/
    %/*For example prob(i)=fitness(i)/sum(fitness)*/
    %/*or in a way used in the method below prob(i)=a*fitness(i)/max(fitness)+b*/
    %/*probability values are calculated by using fitness values and normalized by dividing maximum fitness value*/

    prob=0.5;%(0.9.*Fitness./max(Fitness))+0.1;
end
%=========================================================================
%%%%%%%%%%%%%%%%%%%%%%%% ONLOOKER BEE PHASE1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [trial,GlobalMin,GlobalParams,Fitness,ObjVal,sol,mu,sicma]=OnlookerBeePhase1(prob,trial,sol,Fitness,ObjVal,GlobalMin,GlobalParams,dim,ub,lb,F,NP,mu,sicma)


    x=sol;
    %while(t<FoodNumber)
    if(rand<prob)%(i))      
        for i=1:dim
            x(i)=x(i)+rand*x(i);
        end
            
           %  /*if generated parameter value is out of boundaries, it is shifted onto the boundaries*/           
       x=simplebounds(x,lb,ub);

           %evaluate new solution
%        ObjValSol=feval(funName(FN),x);
       ObjValSol=test_functions(x,F,dim);
       FitnessSol=calculateFitness(ObjValSol);

       if (FitnessSol>Fitness)%(i)) %/*If the mutant solution is better than the current solution i, replace the solution with the mutant and reset the trial counter of solution i*/
            %Foods(i,:)=sol;
            sol=x;
            Fitness=FitnessSol;
            ObjVal=ObjValSol;
            trial=0;
       else
            trial=trial+1; %/*if the solution i can not be improved, increase its trial counter*/
       end

    end           

    if (ObjVal<GlobalMin)
        GlobalMin=ObjVal;
        GlobalParams=sol;
    end
end
%OnlookerBeePhase

%=========================================================================
%%%%%%%%%%%%%%%%%%%%%%%%%%%% SCOUT BEE PHASE1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%/*determine the food sources whose trial counter exceeds the "limit" value. 
%In Basic ABC, only one scout is allowed to occur in each cycle*/
function [sol,Fitness,ObjVal]=ScoutBeePhase1(trial,Fitness,ObjVal,sol,limit,dim,ub,lb,F)
if (trial>limit)    
    %sol=(ub-lb).*rand(i,dim)+lb;
    x=(ub-lb)*rand(dim)+lb;
%     ObjValSol=feval(funName(FN),x);
    ObjValSol=test_functions(x,F,dim);
    FitnessSol=calculateFitness(ObjValSol);
    
    sol=x;
    Fitness=FitnessSol;
    ObjVal=ObjValSol;
end
end
%9999999999999999999999999999999999999999999999999999999999999999999999999
%=========================================================================
%========================end of Compact ABC===============================
%=========================================================================
%compete two individual
function [u,v]=compete(x,y,F,dim)
if test_functions(x,F,dim)<test_functions(y,F,dim)
%if Fun(x,FN)>Fun(y,FN)
    u=x; v=y;
else
    u=y; v=x;
end
end

%================================================
% (winner,loser,meanVector,populationSize,dimention)
function mmu =updateMuPV(win,lost,mu,Np,dim) %update meanVector belong [-1,1]; 
mmu=mu;
for k=1:dim
    dm =(1/Np)*(win(k)-lost(k));
    if (abs(mu(k)+dm)<=1)
        mmu(k)=mu(k)+dm;
    end
end
end
%==================================================
% (winner,loser,meanVector,sigma2Vector,populationSize,dimention)
function ssicma =updateSicmaPV(win,los,mu,sicma,Np,dim) 
%nbit=dim;%length(x);
sicma2=sicma.^2;
ssicma2=sicma2;
mmu=mu;

for k=1:dim%nbit
    dm   =(1/Np)*(win(k)-los(k));
    mmu(k)=mu(k)+dm;
    A=mu(k).^2;
    B=mmu(k).^2;
    C=(1/Np)*(win(k).^2-los(k).^2);
    dsicma2=A-B+C;

    if abs(dsicma2)<sicma2(k)
        ssicma2(k)=sicma2(k)+dsicma2;
    else
        ssicma2(k)=sicma2(k);
    end
    ssicma=sqrt(ssicma2);
end
end


% Application of simple limits/bounds 
function s=simplebounds(s,Lb,Ub)
  % Apply the lower bound vector
  ns_tmp=s;
  I=(ns_tmp<Lb);
  ns_tmp(I)=Lb(I);
  
  % Apply the upper bound vector 
  J=(ns_tmp>Ub);
  ns_tmp(J)=Ub(J);
  % Update this new move 
  s=ns_tmp;
end
%====================================================
function fFitness=calculateFitness(fObjV)
    fFitness=zeros(size(fObjV));
    ind=find(fObjV>=0);
    fFitness(ind)=1./(fObjV(ind)+1);
    ind=find(fObjV<0);
    fFitness(ind)=1+abs(fObjV(ind));
end

function x=generateIndividualR(P,sigma2)
nv=length(P);
x=2*ones(1,nv);

 for i=1:nv
   trial=0;
   while ((abs(x(i))>1) && trial < 10)
       trial=trial+1;
       x(i)=randn*sqrt(sigma2(i))+P(i);
   end
   if (abs(x(i))>1)
       x(i)=truncrndn(rand,P(i),sqrt(sigma2(i)));
   end
 end
 
 function rndfuncout=truncrndn(r,m,sigma)
%y=truncatedrandn(m,sigma,n,nmin,nmax)
%truncatedrandn.m genera n numeri casuali con distribuzione normale a media
%m e deviazione std sigma (varianza sigma^2).
%Nmin ed Nmax sono il valore minimo e massimo del numeri casuali generati.
%
%Questa funzione genera numeri casuali con distribuzione gaussiana
%utilizzando il Teorma dell'Inversione ed una approssimazione razionale
%di Chebyshec della funzione erf(x).
%E.Mininno, 2005

%rndfuncout=1;
nmin=-1; nmax=1;

s1=sqrt(2)*sigma;
pdfmax=(nmax-m)/s1;
pdfmin=(nmin-m)/s1;

umin=myerf(pdfmin);
umax=myerf(pdfmax);

u0=r;
u=umin+(umax-umin).*u0;

me=myerfinv(u);
rndfuncout=s1.*me+m;
 end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function result = myerf(xin)
%ERFCORE Core algorithm for error functions.
%   erf(x) = erfcore(x,0)
%   erfc(x) = erfcore(x,1)
%   erfcx(x) = exp(x^2)*erfc(x) = erfcore(x,2)

%   This is a translation of a FORTRAN program by W. J. Cody,
%   Argonne National Laboratory, NETLIB/SPECFUN, March 19, 1990.
%   The main computation evaluates near-minimax approximations
%   from "Rational Chebyshev approximations for the error function"
%   by W. J. Cody, Math. Comp., 1969, PP. 631-638.


%
%   evaluate  erf  for  |x| <= 0.46875
%
    result=0;
    xbreak = 0.46875;
    if (abs(xin) <= xbreak)
        acoef = [3.16112374387056560e00; 1.13864154151050156e02;
             3.77485237685302021e02; 3.20937758913846947e03;
             1.85777706184603153e-1];
        bcoef = [2.36012909523441209e01; 2.44024637934444173e02;
             1.28261652607737228e03; 2.84423683343917062e03];

            y = abs(xin);
            z = y .* y;
            xnum = acoef(5)*z;
            xden = z;
            for index = 1:3
               xnum = (xnum + acoef(index)) .* z;
               xden = (xden + bcoef(index)) .* z;
            end
            result = xin .* (xnum + acoef(4)) ./ (xden + bcoef(4));
    end
%
%   evaluate  erfc  for 0.46875 <= |x| <= 4.0
%

    if ((abs(xin) > xbreak) &&  (abs(xin) <= 4.))
        ccoef = [5.64188496988670089e-1; 8.88314979438837594e00;
             6.61191906371416295e01; 2.98635138197400131e02;
             8.81952221241769090e02; 1.71204761263407058e03;
             2.05107837782607147e03; 1.23033935479799725e03;
             2.15311535474403846e-8];
        dcoef = [1.57449261107098347e01; 1.17693950891312499e02;
             5.37181101862009858e02; 1.62138957456669019e03;
             3.29079923573345963e03; 4.36261909014324716e03;
             3.43936767414372164e03; 1.23033935480374942e03];

            y = abs(xin);
            xnum = ccoef(9)*y;
            xden = y;
            for index = 1:7
               xnum = (xnum + ccoef(index)) .* y;
               xden = (xden + dcoef(index)) .* y;
            end
            result = (xnum + ccoef(8)) ./ (xden + dcoef(8));
            z = fix(y*16)/16;
            del = (y-z).*(y+z);
            result = exp(-z.*z) .* exp(-del) .* result;
            
    end
%
%   evaluate  erfc  for |x| > 4.0
%

    if (abs(xin) > 4.0)
        p = [3.05326634961232344e-1; 3.60344899949804439e-1;
             1.25781726111229246e-1; 1.60837851487422766e-2;
             6.58749161529837803e-4; 1.63153871373020978e-2];
        q = [2.56852019228982242e00; 1.87295284992346047e00;
             5.27905102951428412e-1; 6.05183413124413191e-2;
             2.33520497626869185e-3];

            y = abs(xin);
            z = 1 ./ (y .* y);
            xnum = p(6).*z;
            xden = z;
            for index = 1:4
               xnum = (xnum + p(index)) .* z;
               xden = (xden + q(index)) .* z;
            end
            result = z .* (xnum + p(5)) ./ (xden + q(5));
            result = (1/sqrt(pi) -  result) ./ y;
            z = fix(y*16)/16;
            del = (y-z).*(y+z);
            result = exp(-z.*z) .* exp(-del) .* result;
    end
%
%   fix up for negative argument, erf, etc.
%
    
if (xin > xbreak)
    result = (0.5 - result) + 0.5;
end

if (xin < -xbreak)
    result = (-0.5 + result) - 0.5;
end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function xo = myerfinv(yo)
%ERFINV Inverse error function.
%   X = ERFINV(Y) is the inverse error function for each element of Y.
%   The inverse error function satisfies y = erf(x), for -1 <= y <= 1
%   and -inf <= x <= inf.
%


xo = 0;

% Coefficients in rational approximations.

acoef = [ 0.886226899 -1.645349621  0.914624893 -0.140543331];
bcoef = [-2.118377725  1.442710462 -0.329097515  0.012229801];
ccoef = [-1.970840454 -1.624906493  3.429567803  1.641345311];
dcoef = [ 3.543889200  1.637067800];

% Central range

y0 = .7;

if (abs(yo) <= y0)
    z = yo.^2;
    xo = yo.* (((acoef(4)*z+acoef(3)).*z+acoef(2)).*z+acoef(1))./((((bcoef(4)*z+bcoef(3)).*z+bcoef(2)).*z+bcoef(1)).*z+1);
end;

% Near end points of range

if (( y0 < yo ) && (yo <  1))
    z = sqrt(-log((1-yo)/2));
    xo = (((ccoef(4)*z+ccoef(3)).*z+ccoef(2)).*z+ccoef(1)) ./ ((dcoef(2)*z+dcoef(1)).*z+1);
end

if ((-y0 > yo ) && (yo > -1))
    z = sqrt(-log((1+yo)/2));
    xo = -(((ccoef(4)*z+ccoef(3)).*z+ccoef(2)).*z+ccoef(1)) ./ ((dcoef(2)*z+dcoef(1)).*z+1);
end
end
