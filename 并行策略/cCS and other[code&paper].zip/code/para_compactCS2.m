function fit_pccs = para_compactCS2(F,Max_gen,Groups)
Np=20;
% Discovery rate of alien eggs/solutions
Pa=0.25;

%PARA_COMPACTCS �˴���ʾ�йش˺�����ժҪ
[down,up,dim]=test_functions_range(F); % Text function range
% Simple Bound of Search dimension
Nd=dim;
if size(up,2)==1
    Lb=down*ones(1,Nd);
    Ub=up*ones(1,Nd);
else
    Lb=down;
    Ub=up;
end


count = 1;
% Groups = 3;
% Groups = Groups;

%��ʼ��
for g = 1:Groups
    group(g).mu = zeros(1,Nd);
    group(g).sicma=10*ones(1,Nd);
    group(g).bestnest=Ub;
    group(g).fmin = Inf;
end
Totalfmin = group(1).fmin;
Totalbestnest = group(1).bestnest;
fit_pccs(count) = Totalfmin;

for t=2:Max_gen
    count = count + 1;
    %ÿһ�����
    for g=1:Groups
        nest=zeros(1,Nd);
        for i =1:Nd
            nest(i)=generateCDFInv(rand,group(g).mu(i),group(g).sicma(i));
            nest(i) = nest(i)*((Ub(i)-Lb(i))/2) + ((Ub(i)+Lb(i))/2);
        end
        newnest=get_cuckoos(nest,group(g).bestnest,Lb,Ub);
        K = rand(1,Nd)>Pa;
        %V6 ��� ���ݸ���ѡ��
        if rand >0.5
            stepsize=rand.*(group(g).bestnest-nest);
            nestempty = newnest + stepsize.*K;
        else
            nestempty = newnest + rand.*randn(1,Nd);
        end
        nestempty=simplebounds(nestempty,Lb,Ub);
        [winner,loser,winner_fit_1]=competetwo(nestempty,nest,F,Nd);
        % update PV
        for i=1:Nd
            % ��һ��
            winner(i) = (winner(i)-(Ub(i)+Lb(i))/2)/((Ub(i)-Lb(i))/2);
            loser(i) = (loser(i)-(Ub(i)+Lb(i))/2)/((Ub(i)-Lb(i))/2);
            mut = group(g).mu(i);
            group(g).mu(i) = mut + (1/Np)*(winner(i)-loser(i));
            %temu = mu(i)
            temp = group(g).sicma(i)^2+mut^2-group(g).mu(i)^2+(1/Np)*(winner(i)^2-loser(i)^2);
            if temp>0
                group(g).sicma(i)=sqrt(temp);
            else
                group(g).sicma(i)=10;
            end
        end 
        [winner,loser,winner_fit]=competetwo(winner,group(g).bestnest,F,Nd);
        group(g).bestnest = winner;
        group(g).fmin = winner_fit;
        
    end
    %ȫ�ָ���
    for g=1:Groups
        if group(g).fmin<Totalfmin
            Totalfmin = group(g).fmin;
            Totalbestnest = group(g).bestnest;
        end
    end
    fit_pccs(count) = Totalfmin;
    % ��佻��
    for g = 1:Groups
        if rand >0.5
            % ���ѡһ���Ƚ�
            SG = randperm(Groups,1);
            if group(g).fmin > group(SG).fmin
                group(g).fmin  = group(SG).fmin;
                group(g).bestnest = group(SG).bestnest;
            else
                new_rd = group(g).bestnest + (dist(Ub,Lb')/50)*rand.*randn(1,Nd);
                fit_rd = test_functions(new_rd,F,Nd);
                if fit_rd < group(g).fmin
                    group(g).fmin = fit_rd;
                    group(g).bestnest = new_rd;
                end
            end
        else
            if group(g).fmin > Totalfmin
                group(g).fmin = Totalfmin;
                group(g).bestnest = Totalbestnest;
            else
                new_rd = group(g).bestnest + (dist(Ub,Lb')/100)*rand.*randn(1,Nd);
                fit_rd = test_functions(new_rd,F,Nd);
                if fit_rd < group(g).fmin
                    group(g).fmin = fit_rd;
                    group(g).bestnest = new_rd;
                end
            end
        end
    end
end
end

function nest=get_cuckoos(nest,best,Lb,Ub)
% Levy flights
n=size(nest,1);
% disp(num2str(n));  25 nest number
% Levy exponent and coefficient
% For details, see equation (2.21), Page 16 (chapter 2) of the book
% X. S. Yang, Nature-Inspired Metaheuristic Algorithms, 2nd Edition, Luniver Press, (2010).
beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);

for j=1:n
    s=nest(j,:);
%     disp(num2str(size(s)));  size(s) = 1,15  
    % This is a simple way of implementing Levy flights
    % For standard random walks, use step=1;
    %% Levy flights by Mantegna's algorithm
    u=randn(size(s))*sigma;
    v=randn(size(s));
    step=u./abs(v).^(1/beta);
  
    % In the next equation, the difference factor (s-best) means that 
    % when the solution is the best solution, it remains unchanged.     
    stepsize=0.01*step.*(s-best);
    % Here the factor 0.01 comes from the fact that L/100 should the typical
    % step size of walks/flights where L is the typical lenghtscale; 
    % otherwise, Levy flights may become too aggresive/efficient, 
    % which makes new solutions (even) jump out side of the design domain 
    % (and thus wasting evaluations).
    % Now the actual random walks or flights
    s=s+stepsize.*randn(size(s));
   % Apply simple bounds/limits
   nest(j,:)=simplebounds(s,Lb,Ub);
end

end
%compete two individual
function [u,v,winner_fit]=competetwo(x,y,F,nd)
% if ccs_object_function(x)<ccs_object_function(y)
fx = test_functions(x,F,nd);
fy = test_functions(y,F,nd);
if fx<fy
    u=x; v=y;
    winner_fit = fx;
else
    u=y; v=x;
    winner_fit = fy;
end
end

function samplerand = generateCDFInv(r,mu,sigma)
% mu = 0;
% sigma = 10;
    erfA = erf((mu+1)/(sqrt(2)*sigma));
    erfB = erf((mu-1)/(sqrt(2)*sigma));
    samplerand = erfinv(-erfA-r*erfB+r*erfA)*sigma*sqrt(2)+mu;
end

% Application of simple constraints
function s=simplebounds(s,Lb,Ub)
  % Apply the lower bound
  ns_tmp=s;
  I=ns_tmp<Lb;
  ns_tmp(I)=Lb(I);
  
  % Apply the upper bounds 
  J=ns_tmp>Ub;
  ns_tmp(J)=Ub(J);
  % Update this new move 
  s=ns_tmp;
end
