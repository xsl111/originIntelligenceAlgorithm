%=======================
%   Compact PSO
%       The-Kien
%=======================
function value_c_pso_test = compact_pso_test(F,Max_gen)
lamda = 10;
phi1 = -0.2;
phi2 = -0.07;
phi3 = 3.74;
gama1 = 1;
gama2 = 1;
Np=200;

%function [best,fmin,N_iter]=cPSO_algorithm(para)
% Display help
%  help cPSO_algorithm.m
 


% d=30;       % Number of dimensions 
[down,up,dim]=test_functions_range(F); % Text function range
% Simple Bound of Search dimension
nd=dim;
if size(up,2)==1
    Lb=down*ones(1,nd);
    Ub=up*ones(1,nd);
else
    Lb=down;
    Ub=up;
end

% Lb=-5*ones(1,d); 
% % Upper bounds
% Ub=5*ones(1,d);

%initialize PV(mu, sicma)
mu=zeros(1,nd);          %mean
sicma=lamda*ones(1,nd);     %standard deviation

%generate xgb by mean PV
count=1;    
xgb=Ub;
xt=rand(1,nd);
vt=rand(1,nd);
value_c_pso_test(count)=test_functions(xgb,F,nd);
for t=2:Max_gen 
    count = count +1;
    
%     xlb=icdf('Normal',rand(1,nd),mu,sicma);  %reverse function of the cdf function;
    for i =1:nd
%         mu(i)
        xlb(i)=generateCDFInv(rand,mu(i),sicma(i));
        xlb(i) = xlb(i)*((Ub(i)-Lb(i))/2) + ((Ub(i)+Lb(i))/2);
    end
    xlb = simplebounds(xlb,Lb,Ub);
    vt=phi1*vt+phi2*rand()*(xlb-xt)+phi3*rand()*(xgb-xt);
    xt=gama1*xt+gama2*vt;
    [winner,loser]=compete(xt,xlb,F,nd);
    
    for i=1:nd
        % ��һ��
        winner(i) = (winner(i)-(Ub(i)+Lb(i))/2)/((Ub(i)-Lb(i))/2);
        loser(i) = (loser(i)-(Ub(i)+Lb(i))/2)/((Ub(i)-Lb(i))/2);
        mut = mu(i);
        mu(i) = mut + (1/Np)*(winner(i)-loser(i));
        %temu = mu(i)
        t = sicma(i)^2+mut^2-mu(i)^2+(1/Np)*(winner(i)^2-loser(i)^2);
        if t>0
            sicma(i)=sqrt(t);
        else
            sicma(i)=10;
        end
%         sicma(i)=sqrt(sicma(i)^2+mu(i)^2-mu(i)^2+1/Np*(winner(i)*loser(i)));
    end 
    
    [winner,loser]=compete(xt,xgb,F,nd);
    xgb=winner;
    
    value_c_pso_test(count)=test_functions(xgb,F,nd);
    
end
% plot(value,'-m');
% save('ccs_value_c_pso_test.mat','value_c_pso_test');      
end
function samplerand = generateCDFInv(r,mu,sigma)
% mu = 0;
% sigma = 10;
    erfA = erf((mu+1)/(sqrt(2)*sigma));
    erfB = erf((mu-1)/(sqrt(2)*sigma));
    samplerand = erfinv(-erfA-r*erfB+r*erfA)*sigma*sqrt(2)+mu;
end
function [a,b]=compete(xt,xlb,F,nd)
    if (test_functions(xt,F,nd)<test_functions(xlb,F,nd))
        a=xt; b=xlb;
    else
        a=xlb; b=xt;
    end
end
% Application of simple constraints
function s=simplebounds(s,Lb,Ub)
  % Apply the lower bound
  ns_tmp=s;
  I=ns_tmp<Lb;
  ns_tmp(I)=Lb(I);
  
  % Apply the upper bounds 
  J=ns_tmp>Ub;
  ns_tmp(J)=Ub(J);
  % Update this new move 
  s=ns_tmp;
end
% Sphere function with fmin=0 at (0,0,...,0)
% function z=finess(u)
%         z=sum((u-1).^2);
% %         z = sum ( abs(u-3) ) + prod( abs(u-3) );
% %         a=sum(z.^2);
% 
% end
 