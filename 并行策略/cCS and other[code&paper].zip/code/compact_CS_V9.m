function fit_ccsV1 = compact_CS_V9(F,Max_gen)
Pa=0.25;
Np = 200;
[down,up,dim]=test_functions_range(F); % Text function range
% Simple Bound of Search dimension
nd=dim;
if size(up,2)==1
    Lb=down*ones(1,nd);
    Ub=up*ones(1,nd);
else
    Lb=down;
    Ub=up;
end

count = 0;
lamda =10;
mu=zeros(1,nd);          %mean
sicma=lamda*ones(1,nd);     %standard deviation

bestnest = Ub;
for t=1:Max_gen
    count = count + 1;
    %����
    nest=zeros(1,nd);
    for i =1:nd
        nest(i)=generateCDFInv(rand,mu(i),sicma(i));
        nest(i) = nest(i)*((Ub(i)-Lb(i))/2) + ((Ub(i)+Lb(i))/2);
    end
    newnest=get_cuckoos(nest,bestnest,Lb,Ub);

    %pa
    K = rand(1,nd)>Pa;
    % V1
        nest2=zeros(1,nd); 
    
    
    if rand>0.25
        for ii = 1:nd
            nestempty(ii) = newnest(ii);
            if rand > Pa
                nestempty(ii) = bestnest(ii);
            end
        end
    else
        stepsize=rand.*(bestnest-newnest);
        nestempty = newnest + stepsize.*K;
    end
    
    nestempty=simplebounds(nestempty,Lb,Ub);
    [winner,loser,winner_fit_1]=competetwo(nestempty,nest,F,nd);
    save_winner = winner;
    % update PV
    for i=1:nd
        % ��һ��
        winner(i) = (winner(i)-(Ub(i)+Lb(i))/2)/((Ub(i)-Lb(i))/2);
        loser(i) = (loser(i)-(Ub(i)+Lb(i))/2)/((Ub(i)-Lb(i))/2);
                mut = mu(i);
        mu(i) = mut + (1/Np)*(winner(i)-loser(i));
        %temu = mu(i)
        t = sicma(i)^2+mut^2-mu(i)^2+(1/Np)*(winner(i)^2-loser(i)^2);
        if t>0
            sicma(i)=sqrt(t);
        else
            sicma(i)=10;
        end
    end 
    [winner,loser,winner_fit]=competetwo(save_winner,bestnest,F,nd);
    bestnest = winner;
    fmin = winner_fit;
    
    fit_ccsV1(count) = fmin;
end

end

function nest=get_cuckoos(nest,best,Lb,Ub)
% Levy flights
n=size(nest,1);
% disp(num2str(n));  25 nest number
% Levy exponent and coefficient
% For details, see equation (2.21), Page 16 (chapter 2) of the book
% X. S. Yang, Nature-Inspired Metaheuristic Algorithms, 2nd Edition, Luniver Press, (2010).
beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);

for j=1:n
    s=nest(j,:);
%     disp(num2str(size(s)));  size(s) = 1,15  
    % This is a simple way of implementing Levy flights
    % For standard random walks, use step=1;
    %% Levy flights by Mantegna's algorithm
    u=randn(size(s))*sigma;
    v=randn(size(s));
    step=u./abs(v).^(1/beta);
  
    % In the next equation, the difference factor (s-best) means that 
    % when the solution is the best solution, it remains unchanged.     
    stepsize=0.01*step.*(s-best);
    % Here the factor 0.01 comes from the fact that L/100 should the typical
    % step size of walks/flights where L is the typical lenghtscale; 
    % otherwise, Levy flights may become too aggresive/efficient, 
    % which makes new solutions (even) jump out side of the design domain 
    % (and thus wasting evaluations).
    % Now the actual random walks or flights
    s=s+stepsize.*randn(size(s));
   % Apply simple bounds/limits
   nest(j,:)=simplebounds(s,Lb,Ub);
end

end
%compete two individual
function [u,v,winner_fit]=competetwo(x,y,F,nd)
% if ccs_object_function(x)<ccs_object_function(y)
fx = test_functions(x,F,nd);
fy = test_functions(y,F,nd);
if fx<fy
    u=x; v=y;
    winner_fit = fx;
else
    u=y; v=x;
    winner_fit = fy;
end
end

function samplerand = generateCDFInv(r,mu,sigma)
% mu = 0;
% sigma = 10;
    erfA = erf((mu+1)/(sqrt(2)*sigma));
    erfB = erf((mu-1)/(sqrt(2)*sigma));
    samplerand = erfinv(-erfA-r*erfB+r*erfA)*sigma*sqrt(2)+mu;
end

% Application of simple constraints
function s=simplebounds(s,Lb,Ub)
  % Apply the lower bound
  ns_tmp=s;
  I=ns_tmp<Lb;
  ns_tmp(I)=Lb(I);
  
  % Apply the upper bounds 
  J=ns_tmp>Ub;
  ns_tmp(J)=Ub(J);
  % Update this new move 
  s=ns_tmp;
end
% (winner,loser,meanVector,populationSize,dimention)
function mmu =updateMuPV(win,lost,mu,Np,dim) %update meanVector belong [-1,1]; 
mmu=mu;
for k=1:dim
    dm =(1/Np)*(win(k)-lost(k));
    if (abs(mu(k)+dm)<=1)
        mmu(k)=mu(k)+dm;
    end
end
end
%==================================================
% (winner,loser,meanVector,sigma2Vector,populationSize,dimention)
function ssicma =updateSicmaPV(win,los,mu,sicma,Np,dim) 
%nbit=dim;%length(x);
sicma2=sicma.^2;
ssicma2=sicma2;
mmu=mu;

for k=1:dim%nbit
    dm   =(1/Np)*(win(k)-los(k));
    mmu(k)=mu(k)+dm;
    A=mu(k).^2;
    B=mmu(k).^2;
    C=(1/Np)*(win(k).^2-los(k).^2);
    dsicma2=A-B+C;

    if abs(dsicma2)<sicma2(k)
        ssicma2(k)=sicma2(k)+dsicma2;
    else
        ssicma2(k)=sicma2(k);
    end
    ssicma=sqrt(ssicma2);
end
end